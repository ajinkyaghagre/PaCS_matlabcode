clear
clc
IA=2401.96;%initial pattern area, user input
crop_size = 16 * 32 - 1;%can be use to crop the image if required, user input
pixel_size = 0.227;%pixel size of the image, user input
pixel_area = pixel_size^2;


%% Basic Functions Setup
lif_load = @ci_loadLif.ci_loadLif;

%export_fig = @export_fig.export_fig;

% read lif images;
load('path.mat', 'filename')
[f, pathname] = uigetfile({'*.lif','Leica Image Format (*.lif)'}, 'Select LIF file', filename);
if ~f, warning('No file selected.'); return; end
filename = [pathname f];
save('path.mat', 'filename');

warning('off', 'Images:initSize:adjustingMag');
% end of lif read code

[pathstr,name,ext] = fileparts(filename);
ResFolder = util.gen_addr(['../Results/' name]);

if ~exist(util.gen_addr(ResFolder), 'dir')
    mkdir(ResFolder)
end

if exist([ResFolder '/ROI.mat'])
load([ResFolder '/ROI.mat'], 'rect', 'xrub', 'yrub');
else
    rect = [];
    xrub = {};
    yrub = {};
end

%start of the main code

%%Getting series number and crops
for task = 1 % task = 1 means user input selections, task = 2 means processing
    
%     if task == 1
%         fprintf('Getting user crop:\n');
% %     else
% %         fprintf('Processing:\n');
%     end
%     
       for pos = [1:3]%series number, user input
        
       for N=1  %N= set of the time frames in the image that needs to be analyzed, user input
       fprintf('\tReading position %d ... ', pos);
        
       [im_ts, npos] = lif_load(filename, pos);       
        imFB_org_ts = im_ts.Image{4}(:,:,N); % channel number
%         imshow(imFB_org_ts)
       
       fprintf('Done!\n\t\t');
       
 
           
%% Get Crop Coordinates (use this section to crop images if necessary)
% title('Crop');
%                 
       imshow(imFB_org_ts(:,:,:,1));
       h = imrect(gca, [0 0 crop_size crop_size]);
       setResizable(h, false);
       rct = wait(h);
       if isempty(rct), warning('No ROI selected.'); return; end
       close, drawnow;
       rect(pos,:) = round(rct);                                                              
       imFB_fin = imcrop(imFB_org_ts, rect(pos,:)); %final cropped image ready for processing                                
       imshow(imFB_fin);
       
       save([ResFolder '/ROI.mat'], 'rect', 'xrub', 'yrub');


Ism = imgaussfilt(imFB_fin,1);% smoothing with guassian filter
imshow(Ism);

IT = imbinarize(Ism,0.3);% thresholding image
IIT=imfill(IT,'holes');
imshow(IIT);
A=bwarea(IIT);% pattern area in pixels
Am=A*pixel_area;% pattern area in microns

% start of area strain energy code
A_int=IA;   %um^2
A_f=Am;    % um^2
G=666.66;    %Substrate Shear moduli Pa, user input
t=0.3;    % pattern thickness in microns estimated based on accuracy of with tfm strain energy values and approximate displacements by cells in z plane

% U_tfm=;  %from TFM

U=abs(2.*G.*A_f.*t.*(1-(A_f./A_int)).*1e-6)%measure strain energy in pJ

%store results
Strainenergy(pos,N)=U;
Area(pos,N)=Am;
       end
       end
end


save([ResFolder '.mat'],'Strainenergy','Area');
